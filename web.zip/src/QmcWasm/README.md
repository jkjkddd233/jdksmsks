# QmcWasm

## 构建

在 Linux 环境下执行 `bash build-wasm` 即可构建。

## Build

Linux environment required. Build wasm binary by execute `bash build-wasm`.
